import { BiometricIDAvailableResult, FingerprintAuthApi, VerifyFingerprintOptions, VerifyFingerprintWithCustomFallbackOptions } from "./fingerprint-auth.common";
export declare class FingerprintAuth implements FingerprintAuthApi {
    available(): Promise<BiometricIDAvailableResult>;
    didFingerprintDatabaseChange(): Promise<boolean>;
    verifyFingerprint(options: VerifyFingerprintOptions): Promise<void>;
    verifyFingerprintWithCustomFallback(options: VerifyFingerprintWithCustomFallbackOptions): Promise<void>;
    private static createKeyChainEntry();
}
