import { BiometricIDAvailableResult, FingerprintAuthApi, VerifyFingerprintOptions, VerifyFingerprintWithCustomFallbackOptions } from "./fingerprint-auth.common";
export declare class FingerprintAuth implements FingerprintAuthApi {
    private keyguardManager;
    private fingerPrintManager;
    constructor();
    available(): Promise<BiometricIDAvailableResult>;
    didFingerprintDatabaseChange(): Promise<boolean>;
    private verifyWithCustomAndroidUI(resolve, reject, authenticationCallback);
    verifyFingerprint(options: VerifyFingerprintOptions): Promise<any>;
    verifyFingerprintWithCustomFallback(options: VerifyFingerprintWithCustomFallbackOptions): Promise<any>;
    private static createKey(options);
    private tryEncrypt(options);
    private showAuthenticationScreen(options);
    private getActivity();
}
