"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var utils = require("tns-core-modules/utils/utils");
var keychainItemIdentifier = "TouchIDKey";
var keychainItemServiceName = null;
var FingerprintAuth = (function () {
    function FingerprintAuth() {
    }
    FingerprintAuth.prototype.available = function () {
        return new Promise(function (resolve, reject) {
            try {
                var laContext = LAContext.new();
                var hasBio = laContext.canEvaluatePolicyError(1);
                resolve({ any: hasBio });
            }
            catch (ex) {
                console.log("fingerprint-auth.available: " + ex);
                resolve({
                    any: false
                });
            }
        });
    };
    FingerprintAuth.prototype.didFingerprintDatabaseChange = function () {
        return new Promise(function (resolve, reject) {
            try {
                var laContext = LAContext.new();
                if (!laContext.canEvaluatePolicyError(1)) {
                    reject("Not available");
                    return;
                }
                if (utils.ios.MajorVersion < 9) {
                    resolve(false);
                    return;
                }
                var FingerprintDatabaseStateKey = "FingerprintDatabaseStateKey";
                var state = laContext.evaluatedPolicyDomainState;
                if (state !== null) {
                    var stateStr = state.base64EncodedStringWithOptions(0);
                    var standardUserDefaults = utils.ios.getter(NSUserDefaults, NSUserDefaults.standardUserDefaults);
                    var storedState = standardUserDefaults.stringForKey(FingerprintDatabaseStateKey);
                    standardUserDefaults.setObjectForKey(stateStr, FingerprintDatabaseStateKey);
                    standardUserDefaults.synchronize();
                    var changed = storedState !== null && stateStr !== storedState;
                    resolve(changed);
                }
            }
            catch (ex) {
                console.log("Error in fingerprint-auth.didFingerprintDatabaseChange: " + ex);
                resolve(false);
            }
        });
    };
    FingerprintAuth.prototype.verifyFingerprint = function (options) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            try {
                if (keychainItemServiceName === null) {
                    var bundleID = utils.ios.getter(NSBundle, NSBundle.mainBundle).infoDictionary.objectForKey("CFBundleIdentifier");
                    keychainItemServiceName = bundleID + ".TouchID";
                }
                if (!FingerprintAuth.createKeyChainEntry()) {
                    _this.verifyFingerprintWithCustomFallback(options).then(resolve, reject);
                    return;
                }
                var query = NSMutableDictionary.alloc().init();
                query.setObjectForKey(kSecClassGenericPassword, kSecClass);
                query.setObjectForKey(keychainItemIdentifier, kSecAttrAccount);
                query.setObjectForKey(keychainItemServiceName, kSecAttrService);
                query.setObjectForKey(options !== null && options.message || "Scan your finger", kSecUseOperationPrompt);
                var res = SecItemCopyMatching(query, null);
                if (res === 0) {
                    resolve();
                }
                else {
                    reject();
                }
            }
            catch (ex) {
                console.log("Error in fingerprint-auth.verifyFingerprint: " + ex);
                reject(ex);
            }
        });
    };
    FingerprintAuth.prototype.verifyFingerprintWithCustomFallback = function (options) {
        return new Promise(function (resolve, reject) {
            try {
                var laContext = LAContext.new();
                if (!laContext.canEvaluatePolicyError(1)) {
                    reject("Not available");
                    return;
                }
                var message = options !== null && options.message || "Scan your finger";
                if (options !== null && options.fallbackMessage) {
                    laContext.localizedFallbackTitle = options.fallbackMessage;
                }
                laContext.evaluatePolicyLocalizedReasonReply(1, message, function (ok, error) {
                    if (ok) {
                        resolve();
                    }
                    else {
                        reject({
                            code: error.code,
                            message: error.localizedDescription,
                        });
                    }
                });
            }
            catch (ex) {
                console.log("Error in fingerprint-auth.verifyFingerprint: " + ex);
                reject(ex);
            }
        });
    };
    FingerprintAuth.createKeyChainEntry = function () {
        var attributes = NSMutableDictionary.new();
        attributes.setObjectForKey(kSecClassGenericPassword, kSecClass);
        attributes.setObjectForKey(keychainItemIdentifier, kSecAttrAccount);
        attributes.setObjectForKey(keychainItemServiceName, kSecAttrService);
        var accessControlRef = SecAccessControlCreateWithFlags(kCFAllocatorDefault, kSecAttrAccessibleWhenUnlockedThisDeviceOnly, 1, null);
        if (accessControlRef === null) {
            console.log("Can't store identifier '" + keychainItemIdentifier + "' in the KeyChain.");
            return false;
        }
        else {
            attributes.setObjectForKey(accessControlRef, kSecAttrAccessControl);
            var content = NSString.stringWithString("dummy content");
            var nsData = content.dataUsingEncoding(NSUTF8StringEncoding);
            attributes.setObjectForKey(nsData, kSecValueData);
            SecItemAdd(attributes, null);
            return true;
        }
    };
    return FingerprintAuth;
}());
exports.FingerprintAuth = FingerprintAuth;
